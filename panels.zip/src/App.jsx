import DashboardDrawersMock from './components/DashboardDrawersMock';
export default function App() {
  return <DashboardDrawersMock />;
}