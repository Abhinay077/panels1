// DashboardDrawersMock component code
// (use version from canvas)
